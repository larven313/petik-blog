import './App.css'
import {BrowserRouter as Router, Routes, Route} from "react-router-dom"
import Blog from './pages/blogs/Blog'
import About from './pages/About'
import Home from './pages'
import DetailBlog from './pages/blogs/DetailBlog'
import ErrorPage from './pages/ErrorPage'

function App() {

  return (
    <>
      <Router>
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/posts" element={<Blog/>} />
          <Route path='/posts/:id' element={<DetailBlog/>} />
          <Route path="/about" element={<About/>} />
          <Route path="*" element={<ErrorPage/>} />
        </Routes>
      </Router>
    </>
  )
}

export default App

import { useState, useEffect } from "react";
import axios from "axios";
import { NavLink } from "react-router-dom";
import Search from "./Search";

const Article = () => {
    const [posts, setPosts] = useState([]);
    const [originalPosts, setOriginalPosts] = useState([]); // Menyimpan data asli
    const [totalPost, setTotalPosts] = useState(0);
    const [authors, setAuthors] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const postsResponse = await axios.get("https://jsonplaceholder.typicode.com/posts");
                const usersResponse = await axios.get("https://jsonplaceholder.typicode.com/users");

                setPosts(postsResponse.data);
                setOriginalPosts(postsResponse.data); // Simpan data asli
                setAuthors(usersResponse.data);
                setTotalPosts(postsResponse.data.length);
            } catch (error) {
                console.error("Error fetching data:", error);
            }
        };

        fetchData();
    }, []);

    const onChangeSearch = (value) => {
        if (value.trim() === "") {
            setPosts(originalPosts); // Jika pencarian dikosongkan, kembalikan data asli
            setTotalPosts(originalPosts.length);
            return;
        }

        const filteredData = originalPosts.filter((post) =>
            post.title.toLowerCase().includes(value.toLowerCase())
        );
        setPosts(filteredData);
        setTotalPosts(filteredData.length);
    };

    return (
        <div>
            <Search onSearchChange={onChangeSearch} totalPost={totalPost} />

            {posts.map((post) => {
                const author = authors.find((user) => user.id === post.userId);
                return (
                    <div key={post.id}>
                        <h3>
                            <NavLink to={`/posts/${post.id}`}>{post.title}</NavLink>
                        </h3>
                        <small>
                            Author: {author ? author.name : "Unknown"} - Date: {post.date || "N/A"} - Tags: {post.tags || "N/A"}
                        </small>
                    </div>
                );
            })}
        </div>
    );
};

export default Article;

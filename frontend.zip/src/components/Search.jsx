import { useState } from "react";

// eslint-disable-next-line react/prop-types
const Search = ({ totalPost, onSearchChange }) => {
    const [search, setSearch] = useState("");

    const handleChangeSearch = (e) => {
        setSearch(e.target.value);

        // Kirim nilai input ke parent (Article)
        onSearchChange(e.target.value);
    };

    return (
        <div>
            Cari artikel: <input type="text" onChange={handleChangeSearch} />
            <br />
            <small>Ditemukan <b>{totalPost}</b> data dengan pencarian kata <b>{search}</b></small>
            <button onClick={() => alert("Hello World")}>Message</button>
        </div>
    );
};

export default Search;

import Navbar from "../components/Navbar"

const ErrorPage = () => {
  return (
    <div>
    <Navbar/>
      <h3>404 Halaman Tidak Ditemukan</h3>
      <p>Oopps... Halaman yang kamu cari tidak ada</p>
    </div>
  )
}

export default ErrorPage

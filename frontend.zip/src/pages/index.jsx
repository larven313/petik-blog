import Navbar from "../components/Navbar";

const Home = () => {
  return (
    <div>
    <Navbar/>
      <h1>Selamat Datang di PeTIK</h1>
      <p>
        Pesantren Teknologi Informasi dan Komunikasi (PeTIK) adalah lembaga pendidikan 
        yang fokus pada pengembangan keterampilan di bidang IT, khususnya web development dan software engineering.
      </p>
      <p>
        Bergabunglah dengan kami dan tingkatkan keahlianmu di dunia digital bersama para mentor dan praktisi industri!
      </p>
    </div>
  );
};

export default Home;

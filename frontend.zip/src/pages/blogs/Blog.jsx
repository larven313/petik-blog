import Article from "../../components/Article"
import Form from "../../components/Form"
import { } from "react-router-dom"
import Navbar from "../../components/Navbar"

const Blog = () => {
  return (
    <div>
        <Navbar/>
        <Article/>
        <br />
        <Form/>
    </div>
  )
}

export default Blog
